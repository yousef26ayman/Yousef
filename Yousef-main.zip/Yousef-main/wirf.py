from turtle import *
import turtle as t
import colorsys 
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
    
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
   
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
   
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
 
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
  
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
    
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
  
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
  
t.bgcolor('black')
speed(4)
tracer(55)
h=0.5
for i in range(100):
    c=colorsys.hsv_to_rgb(h,1,1)
    color(c)
    circle(110-i,100)
    h+=0.005
    t.rt(45)
    t.lt(11)
    t.bk(123)
    circle(110-i,100)
    t.rt(77)
    t.bk(178)
    
t.done()    
  
