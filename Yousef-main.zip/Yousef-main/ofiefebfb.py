import turtle as t
t.bgcolor("maroon")

#orange

def pos(x,y):

    t.penup()

    t.goto(x,y)

    t.pendown()

t.color("black","orange")

pos(0,-200)

t.begin_fill()

t.left(30)

for i in range(15):

    t.right(3)

    t.forward(20)

for i in range(10):

    t.left(4)

    t.forward(20)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(20)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(20)

t.end_fill()

pos(0,-200)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(20)

for i in range(10):

    t.right(4)

    t.back(20)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(20)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(20)

t.end_fill()

#white

t.color("black","white")

pos(0,-250)

t.begin_fill()

t.left(62)

for i in range(15):

    t.right(3)

    t.forward(20)

for i in range(10):

    t.left(4)

    t.forward(20)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(20)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(20)

t.end_fill()

pos(0,-250)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(20)

for i in range(10):

    t.right(4)

    t.back(20)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(20)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(20)

t.end_fill()

#green

t.color("black","green")

pos(0,-300)

t.begin_fill()

t.left(62)

for i in range(15):

    t.right(3)

    t.forward(20)

for i in range(10):

    t.left(4)

    t.forward(20)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(20)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(20)

t.end_fill()

pos(0,-300)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(20)

for i in range(10):

    t.right(4)

    t.back(20)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(20)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(20)

t.end_fill()

#Gold1

t.color("black","gold")

pos(-220,-100)

t.begin_fill()

t.left(62)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(-220,-100)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#Gold2

t.color("black","gold")

pos(-220,-40)

t.begin_fill()

t.left(50)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(-220,-40)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#Gold3

t.color("black","gold")

pos(-210,15)

t.begin_fill()

t.left(50)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(-210,15)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD4

t.color("black","gold")

pos(-190,70)

t.begin_fill()

t.left(50)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(-190,70)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD5

t.color("black","gold")

pos(-150,120)

t.begin_fill()

t.left(45)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(-150,120)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD6

t.color("black","gold")

pos(-80,165)

t.begin_fill()

t.left(40)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(-80,165)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()



#GOLD7

t.color("black","gold")

pos(220,-100)

t.begin_fill()

t.left(135)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(220,-100)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD8

t.color("black","gold")

pos(220,-40)

t.begin_fill()

t.left(75)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(220,-40)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD9

t.color("black","gold")

pos(210,15)

t.begin_fill()

t.left(75)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(210,15)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD10

t.color("black","gold")

pos(190,70)

t.begin_fill()

t.left(75)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(190,70)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD11

t.color("black","gold")

pos(150,120)

t.begin_fill()

t.left(80)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(150,120)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()

#GOLD12

t.color("black","gold")

pos(80,165)

t.begin_fill()

t.left(85)

for i in range(15):

    t.right(3)

    t.forward(7)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(16):

    t.left(3)

    t.back(7)

t.end_fill()

pos(80,165)

t.begin_fill()

t.right(62)

for i in range(15):

    t.left(3)

    t.back(7)

for i in range(10):

    t.right(4)

    t.back(7)

t.right(15)

for i in range(10):

    t.left(4)

    t.forward(7)

t.left(15)

for i in range(16):

    t.right(3)

    t.forward(7)

t.end_fill()



t.hideturtle()

t.exitonclick()