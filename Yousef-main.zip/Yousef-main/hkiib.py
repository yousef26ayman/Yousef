from mendeleev import Si,Na
print("Si's name: ", Si.name,Na.name)
print("Si's atomic number:", Si.atomic_number)
print("Si's atomic weight: ", Si.atomic_weight)
print("Si's valency electron: ", Si.ec.electrons_per_shell())