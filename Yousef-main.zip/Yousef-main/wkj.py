import turtle
t = turtle.Turtle()
turtle.bgcolor('lightCyan')
t.speed(2000)
t.width(3)
for i in range(37):
    t.circle(100)
    t.right(10)
for i in range(37):
    t.circle(150)
    t.right(10)
for i in range(37):
    t.circle(200)
    t.right(10)
for i in range(37):
    t.circle(250)
    t.right(10)

t.done()


