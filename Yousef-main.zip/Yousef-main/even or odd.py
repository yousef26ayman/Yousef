num1 = int(input("Enter your number to check: "))
if num1 % 2 == 0:
    print(f'{num1}' ' is even')
else:
    print(f'{num1}' ' is odd')

